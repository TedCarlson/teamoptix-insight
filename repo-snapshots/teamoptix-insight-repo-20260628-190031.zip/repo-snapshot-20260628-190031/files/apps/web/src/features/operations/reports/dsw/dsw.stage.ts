import type { DswMeta, DswRowKind } from "./dsw.types";
import { cellText } from "./dsw.parse";
import { normalizeDsw, normalizeDswSummary } from "./dsw.normalize";
import { contractCodeFromLabel, summaryScope } from "./dsw.metadata";
import {
  findRouteMatch,
  type DswRouteBaselineRow,
} from "./dsw.routeMatch";
import type { DswClassifiedRow } from "./dsw.classify";

export type DswStagedRouteRow = {
  sheet_name: string;
  source_row_index: number;
  row_kind: DswRowKind;
  parent_source_row_index?: number | null;
  parent_route_key?: string | null;
  parent_wa_number?: string | null;
  parent_driver_name?: string | null;
  raw_row_json: Record<string, unknown>;
  normalized_row_json: ReturnType<typeof normalizeDsw>;
  source_route_key: string | null;
  source_wa_number: string | null;
  source_driver_name: string | null;
  source_dswid: string | null;
};


function numericCell(value: unknown) {
  const n = Number(String(value ?? "").replace(/,/g, "").trim());
  return Number.isFinite(n) ? n : 0;
}

function hasDswActivity(raw: Record<string, unknown>) {
  const driver = cellText(raw["Driver Name"]);
  const deliveryStops = numericCell(raw["Act Del Stps"]);
  const deliveryPackages = numericCell(raw["Act Del Pkgs"]);
  const pickupStops = numericCell(raw["PU Stps"]);
  const pickupPackages = numericCell(raw["VScan Pkgs"]);

  return Boolean(driver) || deliveryStops > 0 || deliveryPackages > 0 || pickupStops > 0 || pickupPackages > 0;
}

export type DswStagedSummaryRow = {
  service_date: string;
  summary_scope: string;
  summary_label: string;
  contract_code: string | null;
  terminal_code: string | null;
  source_row_index: number;
  raw_row_json: Record<string, unknown>;
  normalized_row_json: ReturnType<typeof normalizeDswSummary>;
};

export function buildDswStagedRows(params: {
  rows: DswClassifiedRow[];
  sheetName: string;
  routes: DswRouteBaselineRow[];
  serviceDate: string;
  meta: DswMeta;
}) {
  return params.rows.filter(({ raw }) => hasDswActivity(raw)).map(({
    raw,
    source_row_index,
    row_kind,
    parent_source_row_index,
    parent_route_key,
    parent_wa_number,
    parent_driver_name,
  }) => {
    const routeMatch = findRouteMatch(raw, params.routes, params.serviceDate);
    const normalized = normalizeDsw(raw, routeMatch, params.meta);

    return {
      sheet_name: params.sheetName,
      source_row_index,
      row_kind,
      parent_source_row_index,
      parent_route_key,
      parent_wa_number,
      parent_driver_name,
      raw_row_json: raw,
      normalized_row_json: normalized,
      source_route_key: cellText(raw["WA Name"]) || cellText(raw["WA#"]) || null,
      source_wa_number: cellText(raw["WA#"]) || null,
      source_driver_name: cellText(raw["Driver Name"]) || null,
      source_dswid: cellText(raw["Driver Name"]) || null,
    };
  });
}

export function buildDswStagedSummaryRows(params: {
  rows: DswClassifiedRow[];
  serviceDate: string;
  meta: DswMeta;
}) {
  return params.rows.filter(({ raw }) => hasDswActivity(raw)).map(({
    raw,
    source_row_index,
    row_kind,
    parent_source_row_index,
    parent_route_key,
    parent_wa_number,
    parent_driver_name,
  }) => {
    const label = cellText(raw["Svc Area #"]);
    const scope = summaryScope(label) ?? "SUMMARY";

    return {
      service_date: params.serviceDate,
      summary_scope: scope,
      summary_label: label,
      contract_code: contractCodeFromLabel(label),
      terminal_code: params.meta.terminal_identity,
      source_row_index,
      raw_row_json: raw,
      normalized_row_json: normalizeDswSummary(raw, params.meta),
    };
  });
}

export function countMatchedDswRoutes(rows: DswStagedRouteRow[]) {
  return rows.filter(
    (row) => row.normalized_row_json.route_match_method !== "NONE"
  ).length;
}
